@extends('layouts.tenant_admin_layout') 

@section('title', 'Support')
@section('page-title', 'Support')

@section('content')
<div class="container">
    <h1>Available Updates</h1>
    @foreach ($releases as $release)
        <div class="card my-3">
            <div class="card-body">
                <h4>{{ $release['name'] }}</h4>
                <p>{!! nl2br(e($release['body'])) !!}</p>
                <a href="{{ $release['zipball_url'] }}" class="btn btn-primary" target="_blank">Download Update</a>
            </div>
        </div>
    @endforeach
</div>
@endsection
